import { readBinary } from "@/lib/content-store";

export async function GET(request, context) {
  const { key: keyParts } = await context.params;
  const key = `media/${keyParts.join("/")}`;
  const file = await readBinary(key);

  if (!file) {
    return new Response("Not found", { status: 404 });
  }

  return new Response(file.data, {
    headers: {
      "Content-Type": file.contentType,
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
