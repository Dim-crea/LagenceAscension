# Site Ascension

Site vitrine + page mariage pour L'Agence Ascension, avec un espace d'administration
(`/admin`) pour modifier facilement le portfolio, les prestations, les avis clients et la FAQ,
sans toucher au code.

- **Framework :** Next.js (App Router)
- **Style :** design system "abyssal / bioluminescent" fourni par l'agence (fond
  teal très sombre, dégradés turquoise → lavande, typographie Manrope)
- **Contenu modifiable :** stocké via Netlify Blobs en production (avec repli automatique
  sur des fichiers locaux en développement, aucune configuration nécessaire)
- **Formulaire de contact :** Netlify Forms — gratuit, sans clé API, les messages
  arrivent dans le tableau de bord Netlify et peuvent être transférés par email

## Démarrer en local

```bash
npm install
cp .env.example .env.local   # puis modifiez ADMIN_PASSWORD et ADMIN_SESSION_SECRET
npm run dev
```

Le site est disponible sur http://localhost:3000, la page mariage sur
http://localhost:3000/mariage, et l'administration sur http://localhost:3000/admin
(mot de passe = celui défini dans `.env.local`).

En local, le contenu modifié dans `/admin` est enregistré dans un dossier `.data/`
(non versionné) — c'est uniquement pour le développement, il n'affecte pas le site en ligne.

## Déployer sur Netlify

1. Poussez ce projet sur un dépôt GitHub (ou GitLab/Bitbucket).
2. Sur [app.netlify.com](https://app.netlify.com), cliquez sur **Add new site → Import an
   existing project**, puis choisissez ce dépôt. Netlify détecte automatiquement Next.js
   (grâce au fichier `netlify.toml` déjà présent) — vous pouvez laisser les réglages par défaut.
3. Avant le premier déploiement, ajoutez ces variables d'environnement dans
   **Site configuration → Environment variables** :
   - `ADMIN_PASSWORD` — le mot de passe pour accéder à `/admin`
   - `ADMIN_SESSION_SECRET` — une chaîne aléatoire longue (générez-en une avec
     `openssl rand -base64 32` dans un terminal)
4. Déployez. Netlify Blobs est activé automatiquement, aucune configuration
   supplémentaire n'est nécessaire pour que le contenu géré depuis `/admin` soit sauvegardé.

### Recevoir les messages du formulaire de contact par email

Le formulaire fonctionne automatiquement dès le déploiement (les messages apparaissent
dans **Netlify → votre site → Forms**). Pour les recevoir aussi par email :

1. Allez dans **Site configuration → Forms → Form notifications**.
2. Ajoutez une notification **Email notification**, avec l'adresse
   `contact@lagenceascension.fr` (ou toute autre adresse).

### Nom de domaine

Dans **Domain management**, ajoutez `agence-ascension.fr` (ou votre nom de domaine) et
suivez les instructions Netlify pour pointer vos DNS.

## Gérer le contenu du site

Rendez-vous sur `/admin`, connectez-vous avec le mot de passe défini, puis :

- **Portfolio** — chaque projet devient une carte de la grille de l'accueil (clic = texte + boutons).
  Cochez "Afficher sur la page Mariage" pour qu'il apparaisse sur `/mariage` à la place.
- **Prestations** — les colonnes de la section "Services" (accueil) ou "Prestations" (mariage).
  Les "tags" deviennent la liste affichée sous le titre.
- **Avis clients** — carrousel de témoignages (accueil, ou mariage si coché).
- **FAQ** — page Mariage (cochez "mariage").
- **Réglages** — coordonnées et tous les textes : accueil, mariage, "J'ai un projet" et **Club Ascension**
  (pourquoi le club existe, mission, 4 niveaux, public visé). Dans les textes, `*mot*` = italique accentué,
  et les listes sont séparées par des virgules.

Toute modification est visible immédiatement sur le site, sans redéploiement.

## Pages

| URL | Contenu |
|---|---|
| `/` | Accroche à phrase défilante, bandeau clients, grille de projets (clic = fenêtre avec film, texte et photos), services (arcs qui s'élargissent au scroll), avis, formulaire rapide `quick` (nom, téléphone, projet, budget) |
| `/j-ai-un-projet` | Formulaire seul (Netlify Forms `contact`) |
| `/mariage` | Page mariage : films, prestations, approche, avis, FAQ |
| `/agence` | **Page masquée** (hors menu, non référencée). Pour la publier : décommenter le lien dans `components/moxie/Nav.jsx` et retirer `robots` dans `app/(site)/agence/page.js` |
| `/club` | Club Ascension : ciel de particules, manifeste, escalier des 4 niveaux, jauge d'altitude, formulaire `club` |

## Structure du projet

```
app/(site)/            pages publiques : /, /j-ai-un-projet, /mariage, /club
app/moxie.css          feuille de style du site public (inspirée de moxiegrouppr.com)
app/club.css           styles propres à la page Club
app/admin/              espace d'administration (protégé par mot de passe)
app/api/admin/          API utilisée par l'administration (CRUD + upload d'images)
app/api/media/          sert les images envoyées depuis l'administration
components/moxie/       composants du site public (nav, hero, grille de projets, services sticky…)
components/moxie/club/  composants animés de la page Club
components/admin/       composants réutilisables de l'administration
lib/content.js          lecture/écriture du contenu (projets, services, avis, FAQ, réglages)
lib/content-store.js     Netlify Blobs en production, fichiers locaux en développement
lib/seed-data.js         contenu initial (repris du site précédent)
public/images/           logo et photos optimisées
```

## Notes

- Les dossiers `Asset/` et `index.html` à la racine sont l'ancien site statique et les
  photos originales en haute résolution — ils restent sur votre disque pour référence
  mais ne sont pas utilisés par le nouveau site (et ne sont pas envoyés sur Netlify).
- Les images utilisées sur le site sont des versions optimisées, dans `public/images/`.
